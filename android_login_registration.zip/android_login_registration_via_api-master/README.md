# Android Login & Registration Authenticae via API
A simple and beautiful Login and Registration Form, Authenticate via API
using OkHttp (methods: GET & POST)



## Getting Started
This is for beginners who want to design Login and Registration Forms for all devices and Authenticate using API.
PHP files are included. DB Structure is very simple with 3 columns (1) name  (2) email  (3) password



### Tutorial
You can watch the tutorial here

Part - 1 (Design):
https://www.youtube.com/watch?v=KcdIIoZ9LDM

Part - 2 (Code):
https://www.youtube.com/watch?v=RBAbQMypcRk
